from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from routes import router
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
app = FastAPI(title="ComicCraft AI")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "app" / "static")), name="static")
app.include_router(router)
