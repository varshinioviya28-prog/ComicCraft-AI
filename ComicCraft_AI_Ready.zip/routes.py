from fastapi import APIRouter, Request, Form
from fastapi.templating import Jinja2Templates
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
router = APIRouter()
templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))

@router.get("/")
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"panels": None, "prompt": "", "character": "", "setting": "", "tone": "Adventure", "style": "Anime"}
    )

@router.post("/generate")
async def generate_comic(
    request: Request,
    prompt: str = Form(...),
    character: str = Form(...),
    setting: str = Form(...),
    tone: str = Form("Adventure"),
    style: str = Form("Anime")
):
    prompt = prompt.strip() or "A little cat goes on an adventure"
    character = character.strip() or "Our Hero"
    setting = setting.strip() or "A magical world"

    panels = [
        {"title": "Panel 1 — The Beginning", "description": f"{character} begins an adventure in {setting}. Story idea: {prompt}"},
        {"title": "Panel 2 — A Discovery", "description": f"While exploring {setting}, {character} discovers something unexpected."},
        {"title": "Panel 3 — The Challenge", "description": f"{character} faces a challenge and uses courage and creativity to overcome it."},
        {"title": "Panel 4 — The Ending", "description": f"The adventure ends on a happy note. Tone: {tone}. Art style: {style}."}
    ]

    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "panels": panels, "prompt": prompt, "character": character,
            "setting": setting, "tone": tone, "style": style, "demo_mode": True
        }
    )
