# ComicCraft AI — Ready-to-run demo

This version runs without a Gemini API key. It generates a four-panel sample story from the user's inputs; it does not generate AI images.

## Windows setup
1. Extract this ZIP into a normal folder (for example, Downloads\ComicCraft_AI_Ready).
2. Open that folder in VS Code.
3. Double-click `run.bat`, or open the VS Code terminal in this folder and run:
   `python -m pip install -r requirements.txt`
   `python -m uvicorn main:app --reload`
4. Open http://127.0.0.1:8000 in your browser.
5. Enter a story idea, character, and setting, then press **Generate My Comic**.

Keep `main.py`, `routes.py`, `requirements.txt`, and `app` in the same project folder. Do not run `Main:app`; this version uses lowercase `main:app`.
